---
title: Americana Satire Series
date: 2024-11
materials: After Effects, Premiere Pro
---

A motion graphics series exploring satirical takes on American cultural symbols through kinetic typography and glitch aesthetics.

This project experiments with beat synchronization and text animation to create visual commentary on contemporary americana themes.
