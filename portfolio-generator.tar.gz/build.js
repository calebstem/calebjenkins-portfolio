const fs = require('fs');
const path = require('path');
const { marked } = require('marked');
const matter = require('gray-matter');

// Configuration
const PROJECTS_DIR = './projects';
const OUTPUT_DIR = './output';
const TEMPLATES_DIR = './templates';

// Ensure output directory exists
if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
}

// Get all project types (sculpture, print, digital, photo-video)
function getProjectTypes() {
  return fs.readdirSync(PROJECTS_DIR)
    .filter(file => fs.statSync(path.join(PROJECTS_DIR, file)).isDirectory());
}

// Get all projects within a type
function getProjectsInType(type) {
  const typePath = path.join(PROJECTS_DIR, type);
  return fs.readdirSync(typePath)
    .filter(file => fs.statSync(path.join(typePath, file)).isDirectory())
    .map(projectName => ({
      name: projectName,
      type: type,
      path: path.join(typePath, projectName)
    }));
}

// Parse a project's info.md file
function parseProject(project) {
  const infoPath = path.join(project.path, 'info.md');
  
  if (!fs.existsSync(infoPath)) {
    console.warn(`No info.md found for ${project.name}`);
    return null;
  }
  
  const fileContent = fs.readFileSync(infoPath, 'utf-8');
  const { data, content } = matter(fileContent);
  
  // Get images
  const imagesPath = path.join(project.path, 'images');
  let images = [];
  if (fs.existsSync(imagesPath)) {
    images = fs.readdirSync(imagesPath)
      .filter(file => /\.(jpg|jpeg|png|gif|webp)$/i.test(file))
      .sort();
  }
  
  return {
    ...project,
    title: data.title || project.name,
    date: data.date || '',
    materials: data.materials || '',
    statement: marked(content),
    images: images,
    slug: project.name
  };
}

// Collect all projects
function getAllProjects() {
  const types = getProjectTypes();
  const allProjects = [];
  
  types.forEach(type => {
    const projects = getProjectsInType(type);
    projects.forEach(project => {
      const parsed = parseProject(project);
      if (parsed) {
        allProjects.push(parsed);
      }
    });
  });
  
  return allProjects;
}

// Copy images to output
function copyProjectImages(project) {
  const sourceImages = path.join(project.path, 'images');
  const destImages = path.join(OUTPUT_DIR, project.type, project.slug, 'images');
  
  if (fs.existsSync(sourceImages)) {
    fs.mkdirSync(destImages, { recursive: true });
    
    project.images.forEach(image => {
      fs.copyFileSync(
        path.join(sourceImages, image),
        path.join(destImages, image)
      );
    });
  }
}

// Generate project page HTML
function generateProjectPage(project) {
  const imageGallery = project.images
    .map(img => `<img src="images/${img}" alt="${project.title}">`)
    .join('\n    ');
  
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${project.title} - Portfolio</title>
  <link rel="stylesheet" href="../../style.css">
</head>
<body>
  <nav>
    <a href="../../index.html">← Back to Portfolio</a>
  </nav>
  
  <main class="project">
    <header>
      <h1>${project.title}</h1>
      <div class="meta">
        <span class="type">${project.type}</span>
        <span class="date">${project.date}</span>
        <span class="materials">${project.materials}</span>
      </div>
    </header>
    
    <div class="gallery">
      ${imageGallery}
    </div>
    
    <div class="statement">
      ${project.statement}
    </div>
  </main>
</body>
</html>`;

  const projectDir = path.join(OUTPUT_DIR, project.type, project.slug);
  fs.mkdirSync(projectDir, { recursive: true });
  fs.writeFileSync(path.join(projectDir, 'index.html'), html);
}

// Generate index page HTML
function generateIndexPage(projects) {
  // Group projects by type
  const projectsByType = {};
  projects.forEach(project => {
    if (!projectsByType[project.type]) {
      projectsByType[project.type] = [];
    }
    projectsByType[project.type].push(project);
  });
  
  // Generate project cards
  let projectCards = '';
  Object.keys(projectsByType).sort().forEach(type => {
    projectCards += `\n    <section class="type-section">\n      <h2>${type}</h2>\n      <div class="project-grid">\n`;
    
    projectsByType[type].forEach(project => {
      const thumbnail = project.images[0] || 'placeholder.jpg';
      projectCards += `        <article class="project-card">
          <a href="${project.type}/${project.slug}/index.html">
            <img src="${project.type}/${project.slug}/images/${thumbnail}" alt="${project.title}">
            <h3>${project.title}</h3>
            <p class="date">${project.date}</p>
          </a>
        </article>\n`;
    });
    
    projectCards += `      </div>\n    </section>\n`;
  });
  
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Portfolio</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="site-header">
    <h1>Your Name</h1>
    <p>Graphic Designer</p>
  </header>
  
  <main>
    ${projectCards}
  </main>
</body>
</html>`;

  fs.writeFileSync(path.join(OUTPUT_DIR, 'index.html'), html);
}

// Generate basic CSS
function generateCSS() {
  const css = `* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  line-height: 1.6;
  color: #333;
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
}

/* Header */
.site-header {
  margin-bottom: 3rem;
  border-bottom: 2px solid #333;
  padding-bottom: 1rem;
}

.site-header h1 {
  font-size: 2.5rem;
  margin-bottom: 0.5rem;
}

/* Navigation */
nav {
  margin-bottom: 2rem;
}

nav a {
  text-decoration: none;
  color: #333;
  font-weight: 500;
}

nav a:hover {
  text-decoration: underline;
}

/* Type sections */
.type-section {
  margin-bottom: 4rem;
}

.type-section h2 {
  font-size: 1.5rem;
  margin-bottom: 1.5rem;
  text-transform: capitalize;
}

/* Project grid */
.project-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 2rem;
}

.project-card {
  transition: transform 0.2s;
}

.project-card:hover {
  transform: translateY(-4px);
}

.project-card a {
  text-decoration: none;
  color: inherit;
}

.project-card img {
  width: 100%;
  aspect-ratio: 4/3;
  object-fit: cover;
  margin-bottom: 0.5rem;
}

.project-card h3 {
  font-size: 1.2rem;
  margin-bottom: 0.25rem;
}

.project-card .date {
  color: #666;
  font-size: 0.9rem;
}

/* Project page */
.project header {
  margin-bottom: 2rem;
}

.project h1 {
  font-size: 2rem;
  margin-bottom: 1rem;
}

.meta {
  display: flex;
  gap: 1.5rem;
  color: #666;
}

.meta .type {
  text-transform: capitalize;
  font-weight: 600;
  color: #333;
}

.gallery {
  margin-bottom: 3rem;
}

.gallery img {
  width: 100%;
  margin-bottom: 1rem;
}

.statement {
  max-width: 700px;
  line-height: 1.8;
}

.statement p {
  margin-bottom: 1rem;
}`;

  fs.writeFileSync(path.join(OUTPUT_DIR, 'style.css'), css);
}

// Main build function
function build() {
  console.log('🔨 Building portfolio...\n');
  
  const projects = getAllProjects();
  console.log(`Found ${projects.length} projects\n`);
  
  // Generate each project page
  projects.forEach(project => {
    console.log(`  ✓ ${project.type}/${project.slug}`);
    copyProjectImages(project);
    generateProjectPage(project);
  });
  
  // Generate index page
  generateIndexPage(projects);
  
  // Generate CSS
  generateCSS();
  
  console.log('\n✨ Build complete! Check the output/ folder\n');
}

// Run the build
build();
